# Portfólio Web Dinâmico - Isaac Maciel

Este projeto foi desenvolvido como requisito para a Atividade Final do 4º Bimestre. O objetivo é demonstrar domínio na construção de interfaces Frontend, manipulação de dados no lado do cliente (Client-side) e integração com serviços de automação.

## 🚀 Tecnologias Utilizadas
*   **HTML5 & CSS3:** Estruturação e estilização, com uso de Flexbox e Grid.
*   **Bootstrap 5:** Framework CSS para garantir a responsividade (Mobile First).
*   **JavaScript (Vanilla):** Lógica de programação, manipulação do DOM e CRUD.
*   **LocalStorage:** Armazenamento local dos dados do formulário em formato JSON.
*   **EmailJS:** Ferramenta de automação para disparo de e-mails reais.

## ⚙️ Escolha da Ferramenta de Automação (Etapa 2.2)
Para a notificação do formulário, foi escolhido o **EmailJS**.
**Justificativa:** O EmailJS permite disparar e-mails reais diretamente do lado do cliente (Frontend) sem a necessidade de criar um servidor back-end. Ele se integra facilmente ao JavaScript e possui um plano gratuito de 200 envios/mês, o que é ideal para a validação e uso deste portfólio acadêmico.

## 🕵️‍♂️ Como acessar a Área Administrativa Oculta (CRUD)
Para testar a manipulação de dados (Ler, Atualizar e Deletar as mensagens), o sistema possui um painel administrativo oculto.

**Como acessar:**
1. Role a página até o rodapé.
2. Clique no **ponto final (·)** que fica no centro, logo abaixo dos direitos autorais.
   *(Ou utilize o atalho de teclado: **Ctrl + Shift + A**)*
3. Um modal será aberto exibindo a tabela com todas as mensagens salvas.

*(Nota: O código JavaScript verifica se o LocalStorage está vazio. Se estiver, ele injeta automaticamente **20 registros de teste** para validação imediata do avaliador).*

## 🛠️ Como rodar o projeto localmente
Como o projeto utiliza LocalStorage e bibliotecas externas (CDNs), é recomendável rodá-lo através de um servidor local para evitar bloqueios de segurança do navegador.
1. Abra a pasta do projeto no VS Code.
2. Instale a extensão **Live Server**.
3. Clique com o botão direito no arquivo `index.html` e selecione **"Open with Live Server"**.